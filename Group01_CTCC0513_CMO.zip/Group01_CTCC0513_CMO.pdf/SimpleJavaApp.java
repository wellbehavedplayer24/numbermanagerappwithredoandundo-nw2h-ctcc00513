import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;

public class SimpleJavaApp extends JFrame {
    private final DefaultListModel<Integer> listModel = new DefaultListModel<>();
    private final Stack<Integer> undoStack = new Stack<>();
    private final JList<Integer> numberList = new JList<>(listModel);
    private final JTextField inputField = new JTextField(10);
    private final JButton addButton = new JButton("Add");
    private final JButton undoButton = new JButton("Undo");
    private final JButton sortButton = new JButton("Sort");

    public SimpleJavaApp() {
        setTitle("Simple Java App with GUI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLayout(new BorderLayout());

        // Create the menu bar
        createMenuBar();

        // Top panel for input and buttons
        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("Enter Number:"));
        topPanel.add(inputField);
        topPanel.add(addButton);
        topPanel.add(undoButton);
        topPanel.add(sortButton);
        add(topPanel, BorderLayout.NORTH);

        // Center panel for displaying the list
        JScrollPane scrollPane = new JScrollPane(numberList);
        add(scrollPane, BorderLayout.CENTER);

        // Button actions
        addButton.addActionListener(e -> addNumber());
        undoButton.addActionListener(e -> undoLast());
        sortButton.addActionListener(e -> sortList());
    }

    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        // File menu
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        // Actions menu
        JMenu actionsMenu = new JMenu("Actions");
        JMenuItem addItem = new JMenuItem("Add Number");
        JMenuItem undoItem = new JMenuItem("Undo Last");
        JMenuItem sortItem = new JMenuItem("Sort List");

        addItem.addActionListener(e -> addNumber());
        undoItem.addActionListener(e -> undoLast());
        sortItem.addActionListener(e -> sortList());

        actionsMenu.add(addItem);
        actionsMenu.add(undoItem);
        actionsMenu.add(sortItem);

        // Add menus to the menu bar
        menuBar.add(fileMenu);
        menuBar.add(actionsMenu);

        // Set the menu bar
        setJMenuBar(menuBar);
    }

    private void addNumber() {
        try {
            int number = Integer.parseInt(inputField.getText());
            listModel.addElement(number);
            undoStack.push(number);
            inputField.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void undoLast() {
        if (!undoStack.isEmpty()) {
            int lastNumber = undoStack.pop();
            listModel.removeElement(lastNumber);
        } else {
            JOptionPane.showMessageDialog(this, "Nothing to undo!", "Info", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void sortList() {
        ArrayList<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < listModel.getSize(); i++) {
            numbers.add(listModel.getElementAt(i));
        }
        Collections.sort(numbers);
        listModel.clear();
        for (int num : numbers) {
            listModel.addElement(num);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SimpleJavaApp app = new SimpleJavaApp();
            app.setVisible(true);
        });
    }
}
